from persona import Persona
from producto import Producto
from factura import Factura
from factura_detalle import FacturaDetalle
personas: Persona = []
productos: Producto = []
factutas: Factura = []


def persona():
    dni: str = str(input("Ingrese DNI: "))
    nombres: str = str(input("Ingrese Nombres: "))
    apellidos: str = str(input("Ingrese Apellidos: "))
    direccion: str = str(input("Ingrese Direccion: "))
    telefono: str = str(input("Ingrese Telefono: "))
    persona: Persona = Persona(dni, nombres, apellidos, direccion, telefono)
    personas.append(persona)


def listar_personas():
    for persona in personas:
        Persona.convertir_a_string(persona)


def buscar_persona():
    dni: str = str(input("Ingrese DNI para buscar persona: "))
    for persona in personas:
        if persona.dni == dni:
            Persona.convertir_a_string(persona)
            return persona


def editar_persona():
    dni: str = str(input("Ingrese DNI para buscar persona: "))
    for persona in personas:
        if persona.dni == dni:
            Persona.convertir_a_string(persona)
            persona.nombres = str(input("Ingrese nuevo nombre: "))
            Persona.convertir_a_string(persona)


def eliminar_persona():
    dni: str = str(input("Ingrese DNI para buscar persona: "))
    for indice, persona in enumerate(personas):
        if persona.dni == dni:
            personas.pop(indice)


def producto():
    codigo: str = str(input("Ingrese código del producto: "))
    nombre: str = str(input("Ingrese nombre del producto: "))
    precio: float = float(input("Ingrese precio del producto: "))
    marca: str = str(input("Ingrese marca del producto: "))
    producto: Producto = Producto(codigo, nombre, precio, marca)
    productos.append(producto)


def listar_producto():
    for producto in productos:
        Producto.convertir_a_string(producto)


def buscar_producto():
    codigo: str = str(input("Ingrese Código para buscar el producto: "))
    for producto in productos:
        if producto.codigo == codigo:
            Producto.convertir_a_string(producto)
            return producto


def nueva_factura():
    print("para generar una factura busca un cliente")
    cliente: Persona = buscar_persona()
    factura: Factura = Factura(len(factutas)+1, cliente)
    continuar: bool = True

    while continuar:

        producto: Producto = buscar_producto()
        cantidad: int = int(input("Ingrese la cantidad: "))
        factura.detalle.append(FacturaDetalle(
            producto.codigo, producto.nombre, cantidad, producto.precio,))

        condicion: str = str(input("SI para agregar productos: "))

        if condicion == "SI":
            continuar = True
        else:
            continuar = False
            factura.calcular_igv()
            factutas.append(factura)


def listar_factura():
    for factura in factutas:
        Factura.convertir_a_string(factura)


def buscar_factura():
    numero: int = int(input("Ingrese el numero de la factura: "))
    for factura in factutas:
        if factura.numero == numero:
            Factura.convertir_a_string(factura)
            print("===========================")
            for detalle in factura.detalle:
                FacturaDetalle.convertir_a_string(detalle)


def main():
    continuar: bool = True

    while continuar:
        print("********************************************")
        print("***********💲SISTEMA DE VENTAS💲************ ")
        print("--------------------------------------------")
        print("                QUE SOMOS 🗯                ")
        print("______________________________________________________________________________________")
        print("Somos una empresa de tecnología dedicada a complacer las necesidades de comunicación,|")
        print("postura e incrementación de nuestros clientes. A través de servicios altamente       |")
        print("competitivos, productos de la más alta tecnología y estándares de calidad. Todo es   |")
        print("gracias a la sinergia del equipo profesional que trabaja en conjunto y aplica sus    |")
        print("habilidades para brindar un servicio que deleita a los clientes.                     |")
        print("--------------------------------------------------------------------------------------")
        print("=====================MENÚ===================")
        print("****************INGRESE OPCIONES************")
        print("    PARA AGREGAR   PERSONA   ESCRIBA 1")
        print("    PARA LISTAR    PERSONAS  ESCRIBA 2")
        print("    PARA BUSCAR    PERSONA   ESCRIBA 3")
        print("    PARA EDITAR    PERSONA   ESCRIBA 4")
        print("    PARA ELIMINAR  PERSONA   ESCRIBA 5")
        print("    PARA AGREGAR   PRODUCTO  ESCRIBA 6")
        print("    PARA LISTAR    PRODUCTO  ESCRIBA 7")
        print("    PARA CREAR     FACTURA   ESCRIBA 8")
        print("    PARA LISTAR    FACTURA   ESCRIBA 9")
        print("    PARA BUSCAR    FACTURA   ESCRIBA 10")
        print("    PARA SALIR ESCRIBA 20")
        caso: str = str(input("INGRESE OPCIÓN: "))
        match caso:
            case "1":
                persona()
            case "2":
                listar_personas()
            case "3":
                buscar_persona()
            case "4":
                editar_persona()
            case "5":
                eliminar_persona()
            case "6":
                producto()
            case "7":
                listar_producto()
            case "8":
                nueva_factura()
            case "9":
                print(
                    "____________________________________________________________________________")
                print(
                    "|                                     |    HIGHLAND TECHNOLOGY             |")
                print(
                    "|                                     |    RUC: 20100070970                |")
                print(
                    "|                                     |    HIGHLAND TECHNOLOGY S.A.C.      |")
                print(
                    "|                                     |    Jr. San Martin, Juliaca 21103   |")
                print(
                    "|_____________________________________|____FECHA Y HORA____________________|")
                print(
                    "______________________________________________________________________________________")
                listar_factura()
                print(" ")
                print(
                    "❗❗SI REALIZA UN RECLAMO SOBRE EL PRODUCTO, TIENE '48 HRS' PARA EFECTUARLO❗❗ ")
                print(" ")
            case "10":
                buscar_factura()
            case "20":
                continuar = False


if __name__ == '__main__':
    main()
